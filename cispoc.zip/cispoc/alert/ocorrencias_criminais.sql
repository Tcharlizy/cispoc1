-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 13-Nov-2020 às 04:50
-- Versão do servidor: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csre-db`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrencias_criminais`
--

CREATE TABLE `ocorrencias_criminais` (
  `ID_OCORENCIA` int(11) NOT NULL,
  `DISTRITO` varchar(50) NOT NULL,
  `ID_PROVINCIA` int(11) NOT NULL,
  `CPESSOAS_ACT` int(11) NOT NULL,
  `CPATR_AC_ACT` int(11) NOT NULL,
  `CINFOR_ACT` int(11) NOT NULL,
  `CPERCOM_ACT` int(11) NOT NULL,
  `COTRPUBL_ACT` int(11) NOT NULL,
  `CEXERDEFUN_ACT` int(11) NOT NULL,
  `FALSIDAD_ACT` int(11) NOT NULL,
  `CPESSOAS_ANT` int(11) DEFAULT NULL,
  `CPATR_AC_ANT` int(11) DEFAULT NULL,
  `CINFOR_ANT` int(11) DEFAULT NULL,
  `CPERCOM_ANT` int(11) DEFAULT NULL,
  `COTRPUBL_ANT` int(11) DEFAULT NULL,
  `CEXERDEFUN_ANT` int(11) DEFAULT NULL,
  `FALSIDAD_ANT` int(11) DEFAULT NULL,
  `CRIADO` datetime NOT NULL,
  `MODIFICADO` datetime DEFAULT NULL,
  `ID_USER_CRIADO` int(11) NOT NULL,
  `ID_USER_MODIFICADO` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `ocorrencias_criminais`
--

INSERT INTO `ocorrencias_criminais` (`ID_OCORENCIA`, `DISTRITO`, `ID_PROVINCIA`, `CPESSOAS_ACT`, `CPATR_AC_ACT`, `CINFOR_ACT`, `CPERCOM_ACT`, `COTRPUBL_ACT`, `CEXERDEFUN_ACT`, `FALSIDAD_ACT`, `CPESSOAS_ANT`, `CPATR_AC_ANT`, `CINFOR_ANT`, `CPERCOM_ANT`, `COTRPUBL_ANT`, `CEXERDEFUN_ANT`, `FALSIDAD_ANT`, `CRIADO`, `MODIFICADO`, `ID_USER_CRIADO`, `ID_USER_MODIFICADO`) VALUES
(1, '', 2, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, 0, NULL),
(4, 'Nlhamankulu', 2, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, 0, NULL),
(5, 'Nlhamankulu', 2, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, 0, NULL),
(6, 'KaMpfumu', 2, 11, 11, 11, 11, 11, 11, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, 0, NULL),
(7, 'Nlhamankulu', 2, 1, 11, 1, 1, 11, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-12 23:39:49', NULL, 2, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ocorrencias_criminais`
--
ALTER TABLE `ocorrencias_criminais`
  ADD PRIMARY KEY (`ID_OCORENCIA`),
  ADD KEY `ID_PROVINCIA` (`ID_PROVINCIA`),
  ADD KEY `ID_PROVINCIA_2` (`ID_PROVINCIA`),
  ADD KEY `ID_PROVINCIA_3` (`ID_PROVINCIA`),
  ADD KEY `ID_PROVINCIA_4` (`ID_PROVINCIA`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ocorrencias_criminais`
--
ALTER TABLE `ocorrencias_criminais`
  MODIFY `ID_OCORENCIA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `ocorrencias_criminais`
--
ALTER TABLE `ocorrencias_criminais`
  ADD CONSTRAINT `ocorrencias_criminais_ibfk_1` FOREIGN KEY (`ID_PROVINCIA`) REFERENCES `provincia` (`ID_PROVINCIA`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
